package fact.it.startproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class startprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
