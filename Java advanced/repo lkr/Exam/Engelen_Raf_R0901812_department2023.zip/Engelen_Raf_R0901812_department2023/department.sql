
INSERT INTO `company` VALUES ('PrivateCompany',1,'Antwerpen','Katoen Natie','Fernand Huts',NULL),('PrivateCompany',2,'Ieper','Picanol','Luc Tack',NULL),('PublicCompany',3,'Brussel','NMBS',NULL,_binary ''),('PublicCompany',4,'Brussel','De Lijn',NULL,_binary '\0'),('PublicCompany',5,'Aartselaar','Aquafin',NULL,_binary '\0');

INSERT INTO `employee` VALUES (1,'John',2000),(2,'Anna',3000),(3,'Peter',4000),(4,'Sofie',5000),(5,'Jan',6000),(6,'Piet',7000),(7,'Joris',8000),(8,'Jef',2000),(9,'Mary',2020),(10,'Chris',2030),(11,'Sandra',2040),(12,'Will',3000),(13,'Sara',3020),(14,'Joke',3030),(15,'George',3040),(16,'Jules',4000),(17,'Lilly',4020),(18,'Lotte',4030),(19,'Lies',4040);
INSERT INTO `department` VALUES (1,'IT','Information Technology',4),(2,'HR','Human Resources',1),(3,'SAL','Sales',2),(4,'MAR','Marketing',3),(5,'FIN','Finance',3),(6,'LOG','Logistics',5),(7,'PRO','Production',5),(8,'R&D','Research and Development',5),(9,'PUR','Purchasing',5),(10,'QA','Quality Assurance',2),(11,'CS','Customer Service',2),(12,'ADM','Administration',2),(13,'LEG','Legal',5);
INSERT INTO `department_employees` VALUES (1,1),(1,2),(2,3),(2,4),(3,5),(3,6),(4,7),(5,8),(5,9),(5,10),(6,11),(6,12),(6,13),(7,14),(7,15),(7,16);

