package fact.it.startproject.model;

// AttackStrategy interface
public interface AttackStrategy {
    public String attack();
    public String getWeapon();
}