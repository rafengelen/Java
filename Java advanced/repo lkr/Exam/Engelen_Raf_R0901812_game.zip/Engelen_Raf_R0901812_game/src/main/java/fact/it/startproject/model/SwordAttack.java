package fact.it.startproject.model;

// SwordAttack class
public class SwordAttack implements AttackStrategy {
    @Override
    public String attack() {
        return null;
    }

    @Override
    public String getWeapon() {
        return "sword";
    }
}