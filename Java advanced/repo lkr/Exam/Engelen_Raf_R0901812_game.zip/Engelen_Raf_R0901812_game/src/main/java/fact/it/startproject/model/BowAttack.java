package fact.it.startproject.model;

// BowAttack class
public class BowAttack implements AttackStrategy {
    @Override
    public String attack() {
        return null;
    }

    @Override
    public String getWeapon() {
        return "bow";
    }
}