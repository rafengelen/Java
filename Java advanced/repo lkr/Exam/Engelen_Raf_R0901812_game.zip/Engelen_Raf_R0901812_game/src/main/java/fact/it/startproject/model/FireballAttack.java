package fact.it.startproject.model;

// FireballAttack class
public class FireballAttack implements AttackStrategy{

    @Override
    public String attack() {
        return null;
    }

    @Override
    public String getWeapon() {
        return "fireball";
    }
}